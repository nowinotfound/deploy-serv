## General
+ Bed cannot skip night anymore
+ All hostile mobs can follow and detect players from far distance & move faster
+ Passive mobs like Cows, Chickens, Sheep or etc... will fight back when player killed one of them
+ More types of jockey & jockey will summon more often
+ If players is swimming - travelling in the ocean, Mobs riding a boat have a chance to summon : Boats Riders can use boat to chase players. Boats Rider can be Zombie,Skeletons,etc...
+ Spider, Phantom and Enderman can become transparent : Which made them more horifying and harder to fight


## Zombie & Husk
+ Zombie & Husk can place block - pillar up to follow its target
+ Zombie & Husk can break block if needed to follow its target
+ Zombie & Husk can throw tnt
+ Prevent zombie from burning in sunlight
+ Zombie & Husk has a new ability, which can make zombie use ender pearl, flint & steel, etc...
+ Zombie & Husk will summon more often

## Skeleton
+ Skeleton can fire an arrow from the sky into its target (Cooldown)
+ Skeleton can swap between bow/sword for far/near target
+ Prevent skeleton from burning in sunlight

## Creeper
+ Creeper can explode even if its target is behind the wall
+ Creeper can shoot snowball : Work perfectly with [CoffeeG's Useful Snowball](https://modrinth.com/datapack/usefulsnowball) mod
+ Creeper can randomly spawn as Powered Creeper
+ Creeper can disguide as Passive mob like Cow, sheep, chicken,etc...

## Spider
+ Spider can shoot web into its target (Cooldown)
## Enderman
+ Enderman can curse its target (Random - Long cooldown) : After a while , the cursed target will be attacked by a NIGHTMARE enderman
+ Enderman can teleport its target (Cooldown)


## Drowned
+ Drowned can pull its target backward (Cooldown)
+ Drowned can curse its target (Random - Long cooldown) : After a short time, the cursed target will be pulled into the ocean

## Blaze
+ Blaze can split into two blazes on death : Splited Blaze can not split anymore
+ Blaze can spawn at overworld


## Silverfish
+ Silverfish can parasite its target (Small Chance) : The parasited target will take damage ~4 heart after ~30sec. Then 2x Parasited Silverfish will summon.

## Phantom
+ Fire Phantom has chances to summon while player is sleeping : Fire Phantom is immune to fire
+ Phantom can pull its target up a high distance and drop it down
+ Fire Phantom will summon normally : Fire Phantom is immune to fire

## Others
+ Slime can shoot slimeball
+ Ghast can shoot multiple fireball
+ Illusioner can randomly spawn
+ Wither Skeleton can slow its nearby target

 
# Mini bosses
## Witch 
+ (Mini boss) Witch can become Master Witch when target is nearby (Small Chance)
  + Master Witch can cast various spells
## Vindicator
+ (Mini boss) Nightmare Vindicator : 'Crying angel'
  +  Nightmare Vindicator cannot be killed and will do nothing when it's freezing. But if any players moving nearby, it will 'unfreeze'. You can stop its moving by looking at ITS EYES. Or place a torch under the statue to make it 'freezing' again. It'll disappear if it got "frozen" by torch 5 times.

