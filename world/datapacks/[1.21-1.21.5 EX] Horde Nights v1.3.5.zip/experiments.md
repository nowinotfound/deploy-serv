# 100% Support for 1.21-1.21.5

# Experimental support for 1.21.6 snapshots(up to 25w19a)